package edu.purdue.cs.bash_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BashServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BashServiceApplication.class, args);
	}

}
