package edu.purdue.cs.image_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
